<?php
if (!file_exists('apikey.txt')) sendMsg("Buat file apikey.txt dulu");
$apikey = file_get_contents('apikey.txt');

if (empty($apikey)) sendMsg("Masukin apikey dulu di apikey.txt");

$headers = [
	'accept: application/json',
	'api-key: '.$apikey
];

reqquery:
$query = readline("Query (Dork) : ");

$no = 0;
for ($i=0; $i <= 99999999; $i++) { 
	$search = get2("https://leakix.net/search?scope=leak&page=$i&q=".urlencode($query),$headers);
	if (empty($search) OR $search == "" OR $search == null) sendMsg("Done! Max Page $i");
	if (preg_match("/Invalid API key/i", $search)) sendMsg("Invalid API key");
	$json = json_decode($search,true);
	$no++;

	for ($i2=0; $i2 <= count($json)-1; $i2++) {
		$event_source = $json[$i2]['event_source'];
		$ip = $json[$i2]['ip'];
		$protocol = $json[$i2]['protocol'];
		$domain = $json[$i2]['host'];

        file_put_contents("result.txt", "$protocol://$domain/.env".PHP_EOL, FILE_APPEND);
		echo "[$no] | [$domain - $ip] | [$event_source] | $protocol -> SAVED".PHP_EOL;
	}
}

function sendMsg($text) {
    echo $text;exit();
}

function post($url,$data){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $res = curl_exec($ch);
    return $res;
}

function get($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    return $res;
}

function post2($url,$data,$headers){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $res = curl_exec($ch);
    return $res;
}

function get2($url,$headers){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $res = curl_exec($ch);
    return $res;
}

function random($jumlah) {
    return substr(str_shuffle('1234567890'), 0, $jumlah);
}
?>